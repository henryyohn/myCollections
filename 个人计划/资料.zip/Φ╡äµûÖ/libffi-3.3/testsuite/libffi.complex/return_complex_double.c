/* Area:	ffi_call
   Purpose:	Check return value complex.
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_double.inc"
#include "return_complex.inc"
