#ifdef __arm64__

#include "ffi_arm64.h"


#endif
#ifdef __i386__

#include "ffi_i386.h"


#endif
#ifdef __arm__

#include "ffi_armv7.h"


#endif
#ifdef __x86_64__

#include "ffi_x86_64.h"


#endif
