import React, {useState} from "react";
// import HooksPage from "./pages/HooksPage";
// import ReactReduxPage from "./pages/ReactReduxPage";
import ReduxHooksPage from "./pages/ReduxHooksPage";

export default function App(props) {
  return (
    <div>
      {/* <HooksPage /> */}
      {/* <ReactReduxPage /> */}
      <ReduxHooksPage />
    </div>
  );
}
