import React from "react";

export default function Prompt(props) {
  return (
    <div>
      <h3>Prompt</h3>
    </div>
  );
}
