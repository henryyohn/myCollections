step1. git clone https://github.com/bubucuo/kkb-react.git
step2. 切换对应分支
