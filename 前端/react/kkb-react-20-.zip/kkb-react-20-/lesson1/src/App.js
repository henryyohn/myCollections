import React from "react";
import DialogPage from "./pages/DialogPage";

export default function App(props) {
  return (
    <div>
      {/* <ContextPage /> */}
      {/* <AntdFormPage /> */}
      {/* <MyRCFieldForm /> */}
      <DialogPage />
    </div>
  );
}
